
# CATATAN ( NOTE )
sc ini hanyalah hasil recode dari sc asli hisoka
zens hanya menambahkan sedikit fitur, memperbagus & menyeting banyak hal
agar tidak terjadi error

#ZensBOT
Script WhatsApp Bot Multi Device

## NOTE
This Script is for everyone, not for Sale. Jika dijual kamu kontoll brother !


<a href="https://visitor-badge.glitch.me/badge?page_id=RaaaGH/ZensBot"><img title="Visitor" src="https://visitor-badge.glitch.me/badge?page_id=RaaaGH/Albedo-BOT"></a>
